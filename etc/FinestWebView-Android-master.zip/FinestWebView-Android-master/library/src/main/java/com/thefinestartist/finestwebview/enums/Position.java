package com.thefinestartist.finestwebview.enums;

/**
 * Created by Leonardo on 11/14/15.
 */
public enum Position {
  TOP_OF_TOOLBAR,
  BOTTON_OF_TOOLBAR,
  TOP_OF_WEBVIEW,
  BOTTOM_OF_WEBVIEW;
}
